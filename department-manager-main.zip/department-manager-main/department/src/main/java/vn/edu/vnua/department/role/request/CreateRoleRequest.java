package vn.edu.vnua.department.role.request;

import lombok.Data;

@Data
public class CreateRoleRequest {
    private String id;
    private String name;
}

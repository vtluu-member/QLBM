package vn.edu.vnua.department.role.entity;

import lombok.Data;

@Data
public class RoleDTO {
    private String id;
    private String name;
}

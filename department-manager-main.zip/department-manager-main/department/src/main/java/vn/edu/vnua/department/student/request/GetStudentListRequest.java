package vn.edu.vnua.department.student.request;

import lombok.Data;

@Data
public class GetStudentListRequest {
    private Long internId;
}

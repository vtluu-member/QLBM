package vn.edu.vnua.department.faculty.request;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import vn.edu.vnua.department.request.GetPageBaseRequest;

@Data
@RequiredArgsConstructor
public class GetFacultyListRequest extends GetPageBaseRequest {
}

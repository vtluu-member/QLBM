package vn.edu.vnua.department.masterdata.entity;

import lombok.Data;

@Data
public class MasterDataDTO {
    private Long id;
    private String name;
    private String type;
}

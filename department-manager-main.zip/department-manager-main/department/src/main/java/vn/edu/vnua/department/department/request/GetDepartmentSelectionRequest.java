package vn.edu.vnua.department.department.request;

import lombok.Data;

@Data
public class GetDepartmentSelectionRequest {
    private String facultyId;
}

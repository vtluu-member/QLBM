package vn.edu.vnua.department;

import vn.edu.vnua.department.util.MyUtils;

import java.io.IOException;
import java.text.ParseException;

public class Test {
    public static void main(String[] args) throws ParseException, IOException {
        MyUtils myUtils = new MyUtils();
        myUtils.test("25/6/2023");
    }
}
